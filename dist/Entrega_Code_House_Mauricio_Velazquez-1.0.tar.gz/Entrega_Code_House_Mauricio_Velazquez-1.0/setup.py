from setuptools import setup

setup(
    name='Entrega_Code_House_Mauricio_Velazquez',
    version='1.0',
    description='Funcionamiento de paquertes ',
    author='Mauricio Velazquez',
    author_email='velazquez_257@hotmail.com',
    url='https://github.com/Maurivelaz/Python-CodeHouse',
    packages=['my_package', 'my_package.SegundaEntregaMauricioVelazquez', 'my_package.PrimeraEntrega']
    )